#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#
library(tidyverse)
library(gridExtra)
library(ggthemes)
library(ggmap)
library(forcats)
library(ISOcodes)
data("ISO_3166_1")
pisa_gap <- read_csv("pisa_gap.csv")
pisa_gap <- pisa_gap %>%
  mutate(Name = fct_reorder(Name, mathgap)) %>%
  mutate(direction=ifelse(mathgap>0, "boys", "girls"))
world_map <- map_data("world")

pisa_gap <- pisa_gap %>%
  mutate(Name = recode(Name, "Czechia"="Czech Republic",
                       "Korea, Republic of"="South Korea",
                       "Macedonia, Republic of"="Macedonia",
                       "Moldova, Republic of"="Moldova",
                       "Russian Federation"="Russia",
                       "Taiwan, Province of China"="Taiwan",
                       "Trinidad and Tobago"="Trinidad",
                       "United States"="USA",
                       "United Kingdom"="UK",
                       "Viet Nam"="Vietnam"))
world_map$region[world_map$subregion == "Hong Kong"] <- "Hong Kong"
world_map$region[world_map$subregion == "Macao"] <- "Macao"
to_map <- left_join(world_map, pisa_gap, by=c("region"="Name"))
realvars <- c("math_m", "math_f", "read_m", "read_f",
              "science_m", "science_f",
              "mathgap", "readgap", "sciencegap")

library(shiny)
library(viridis)

# Define UI for application, a sidebar with a menu, and
# a main panel for the resulting plot
ui <- fluidPage(

   # Application title
   titlePanel("PISA Scores across the globe"),

   # Sidebar with a slider input for number of bins
   sidebarLayout(
      sidebarPanel(
        selectInput('y', 'Colour by', realvars)
      ),

      # Show a plot of the generated distribution
      mainPanel(
         plotOutput("map")
      )
   )
)

# Define server logic required to draw a map
server <- function(input, output) {

   output$map <- renderPlot({

     p <- ggplot(to_map, aes(map_id = region)) +
       geom_map(aes_string(fill=input$y), map = world_map,
                color="grey70", size=0.1) +
       scale_fill_viridis(na.value="grey99",
                          limits=c(300,600)) +
       expand_limits(x = world_map$long, y = world_map$lat) +
       theme_few() +
       theme(legend.position = "bottom",
             legend.key.width=unit(1.5, "cm"),
             axis.ticks = element_blank(),
             axis.title = element_blank(),
             axis.text =  element_blank())
     if (grepl("gap", input$y))
       p <- p + scale_fill_gradient2(low="#c51b7d",
                                     high="#4d9221",
                                     mid="#e0e0e0",
                                     na.value="grey99",
                                     limits=c(-73, 30))
     p
   })
}

# Run the application
shinyApp(ui = ui, server = server)

